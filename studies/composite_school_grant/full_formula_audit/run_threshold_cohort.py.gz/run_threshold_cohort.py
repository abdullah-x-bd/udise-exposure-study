from __future__ import annotations

import csv
import json
import math
import os
import runpy
import shutil
import tempfile
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
import statsmodels.api as sm
from rdrobust import rdrobust
from statsmodels.stats.multitest import multipletests

P = runpy.run_path('studies/composite_school_grant/scripts/03_build_panel.py', run_name='full_formula_panel_lib')
S = runpy.run_path('studies/composite_school_grant/social_equity/run_social_equity.py', run_name='full_formula_social_lib')
CF = runpy.run_path('studies/composite_school_grant/confirmatory_experiments/run_confirmatory.py', run_name='full_formula_confirm_lib')

YEARS = P['YEARS']
extract_archive = P['extract_archive']
csv_source = P['csv_source']
source_columns = P['source_columns']
qid = P['qid']
lit = P['lit']
ref = P['ref']
nref = P['nref']

build_composition_year = S['build_composition_year']
load_financial_year = S['load_financial_year']
GROUPS = S['GROUPS']
UNIVERSES = S['UNIVERSES']
BROAD_STATE = S['BROAD_STATE']
CORE_STATE_LOCAL = S['CORE_STATE_LOCAL']
ALL_UDISE_GOVERNMENT = S['ALL_UDISE_GOVERNMENT']
component_exprs = CF['component_exprs']
total_enrolment_setup = CF['total_enrolment_setup']

ASSETS = [
    'water_functional', 'handwash_meal', 'electricity', 'internet', 'library',
    'ramps', 'handrails', 'girls_toilet_full', 'boys_toilet_full',
]

# end_of_lower_band, lower target, upper target, canonical bandwidth
SCHEDULE = [
    {'label':'30_31', 'end':30, 'lower':10000, 'upper':25000, 'jump':15000, 'bw':10,
     'interpretation':'administrative_formula; historical rule must be verified cohort-by-cohort; PM POSHAN 25/26 is nearby'},
    {'label':'100_101', 'end':100, 'lower':25000, 'upper':50000, 'jump':25000, 'bw':20,
     'interpretation':'administrative_formula; downstream causal CSG interpretation confounded by PM POSHAN rules at 100/101'},
    {'label':'250_251', 'end':250, 'lower':50000, 'upper':75000, 'jump':25000, 'bw':30,
     'interpretation':'primary quasi-experimental CSG boundary; PM POSHAN overlap tested with Classes I-VIII restrictions'},
    {'label':'1000_1001', 'end':1000, 'lower':75000, 'upper':100000, 'jump':25000, 'bw':100,
     'interpretation':'administrative_formula; sparse upper tail and PM POSHAN 100-pupil increment rules limit downstream causal interpretation'},
]


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)


def school_id(cols: dict[str,str]) -> str:
    x=cols.get('pseudocode') or cols.get('psuedocode')
    if not x: raise RuntimeError('school identifier missing')
    return x


def e8_expr(cols: dict[str,str]) -> str:
    terms=[f"COALESCE({nref(cols,f'c{k}_{s}')},0)" for k in range(1,9) for s in ('b','g') if f'c{k}_{s}' in cols]
    if not terms: raise RuntimeError('Classes I-VIII columns missing')
    return ' + '.join(terms)


def build_e8_year(con, repo, token, year, work: Path, outdir: Path) -> Path:
    en = csv_source(extract_archive(repo, token, year, 'enrolment_1', work))
    ec = source_columns(con, en); sid=school_id(ec)
    total_expr, filt, _ = total_enrolment_setup(con, en, ec)
    e8=e8_expr(ec)
    p=outdir/'aux'/f'e8_{year}.parquet'; p.parent.mkdir(parents=True, exist_ok=True)
    con.execute(f"""
      COPY (
        SELECT CAST({qid(sid)} AS VARCHAR) pseudocode,
               SUM({total_expr}) enrol_check,
               SUM({e8}) enrol18
        FROM {en} WHERE {filt} GROUP BY 1
      ) TO {lit(str(p))} (FORMAT PARQUET, COMPRESSION ZSTD)
    """)
    return p


def build_asset_year(con, repo, token, year, work: Path, outdir: Path) -> Path:
    fac=csv_source(extract_archive(repo, token, year, 'facility', work))
    fc=source_columns(con,fac); fid=school_id(fc); ce=component_exprs(fc,'f')
    sel=','.join(f'{v} AS {k}' for k,v in ce.items() if k in ASSETS)
    p=outdir/'assets'/f'{year}.parquet'; p.parent.mkdir(parents=True, exist_ok=True)
    con.execute(f"COPY (SELECT CAST(f.{qid(fid)} AS VARCHAR) pseudocode,{sel} FROM {fac} f) TO {lit(str(p))} (FORMAT PARQUET,COMPRESSION ZSTD)")
    return p


def normal_p(t: float) -> float:
    return math.erfc(abs(float(t))/math.sqrt(2))


def pull_last(r, attr):
    a=np.asarray(getattr(r,attr),dtype=float)
    if attr=='ci': return a.reshape(-1,2)[-1].tolist()
    return float(a.reshape(-1)[-1])


def fit_rdrobust(y, x, state, cutoff, bw) -> dict | None:
    y=np.asarray(y,float); x=np.asarray(x,float); st=pd.Series(state,dtype='object')
    m=np.isfinite(y)&np.isfinite(x)&st.notna().to_numpy()&(np.abs(x-cutoff)<=bw)
    y=y[m]; x=x[m]; st=st.to_numpy()[m]
    if len(y)<250 or (x<cutoff).sum()<70 or (x>=cutoff).sum()<70 or pd.Series(st).nunique()<8: return None
    try:
        r=rdrobust(y=y,x=x,c=cutoff,p=1,q=2,kernel='tri',h=bw,b=max(bw*1.5,bw+5),
                   cluster=pd.Categorical(st).codes,vce='cr3',masspoints='adjust',bwcheck=max(5,min(20,int(round(bw/2)))))
        ci=pull_last(r,'ci')
        return {'tau':pull_last(r,'coef'),'se':pull_last(r,'se'),'p':pull_last(r,'pv'),
                'ci_low':ci[0],'ci_high':ci[1],'n':len(y),'n_left':int((x<cutoff).sum()),
                'n_right':int((x>=cutoff).sum()),'clusters':int(pd.Series(st).nunique()),'estimator':'rdrobust_cr3'}
    except Exception as e:
        return {'error':repr(e),'n':len(y),'estimator':'rdrobust_cr3'}


def fit_local(df: pd.DataFrame, ycol: str, cutoff: float, bw: float, cluster_col: str | None='state') -> dict | None:
    d=df.copy()
    d=d[np.isfinite(pd.to_numeric(d[ycol],errors='coerce')) & np.isfinite(pd.to_numeric(d.enrol,errors='coerce'))]
    d=d[np.abs(d.enrol-cutoff)<=bw].copy()
    if len(d)<120 or (d.enrol<cutoff).sum()<35 or (d.enrol>=cutoff).sum()<35: return None
    d['T']=(d.enrol>=cutoff).astype(float); d['z']=d.enrol-cutoff; d['Tz']=d.T*0; d['Tz']=d['T']*d['z']; d['w']=np.maximum(0,1-np.abs(d.z)/bw)
    X=np.c_[np.ones(len(d)),d.T.to_numpy(float)[:,0] if isinstance(d.T,pd.DataFrame) else d['T'].to_numpy(float),d.z,d.Tz]
    # The expression above protects against pandas' .T attribute ambiguity; overwrite cleanly.
    X=np.c_[np.ones(len(d)),d['T'].to_numpy(float),d['z'].to_numpy(float),d['Tz'].to_numpy(float)]
    y=d[ycol].to_numpy(float); model=sm.WLS(y,X,weights=d.w.to_numpy(float))
    if cluster_col and cluster_col in d and d[cluster_col].notna().sum()>0 and d[cluster_col].astype(str).nunique()>=8:
        fit=model.fit(cov_type='cluster',cov_kwds={'groups':d[cluster_col].astype(str).to_numpy(),'use_correction':True})
        cov=f'cluster_{cluster_col}'
    else:
        fit=model.fit(cov_type='HC3'); cov='HC3'
    tau=float(fit.params[1]); se=float(fit.bse[1]); p=float(fit.pvalues[1])
    return {'tau':tau,'se':se,'p':p,'ci_low':tau-1.96*se,'ci_high':tau+1.96*se,
            'n':int(fit.nobs),'n_left':int((d.enrol<cutoff).sum()),'n_right':int((d.enrol>=cutoff).sum()),
            'clusters':int(d[cluster_col].astype(str).nunique()) if cluster_col and cluster_col in d else None,
            'estimator':f'local_linear_{cov}'}


def universe_mask(series: pd.Series, codes: set[int]) -> pd.Series:
    return pd.to_numeric(series,errors='coerce').isin(codes)


def pm_safe_mask(df: pd.DataFrame, end: int, variant: str='primary') -> np.ndarray:
    e8=pd.to_numeric(df.enrol18,errors='coerce').to_numpy(float)
    if end==30:
        lim=20 if variant=='primary' else 18
        return np.isfinite(e8)&(e8<=lim)
    if end==100:
        lim=80 if variant=='primary' else 70
        return np.isfinite(e8)&(e8<=lim)
    if end==250:
        lim=220 if variant=='primary' else 200
        return np.isfinite(e8)&(e8<=lim)
    # For the 1000 boundary, keep I-VIII enrolment away from every PM POSHAN 100-pupil step.
    finite=np.isfinite(e8); dist=np.full(len(e8),np.inf)
    for k in range(100,1101,100): dist=np.minimum(dist,np.abs(e8-k))
    gap=20 if variant=='primary' else 30
    return finite&(dist>gap)


def generalized_social_interaction(df: pd.DataFrame, share_col: str, cutoff: float, bw: float, target: float) -> dict | None:
    d=df.copy(); d=d[np.isfinite(d.receipt)&np.isfinite(d[share_col])&np.isfinite(d.enrol)]
    d=d[np.abs(d.enrol-cutoff)<=bw].copy()
    if len(d)<1000: return None
    d['T']=(d.enrol>=cutoff).astype(float); d['z']=d.enrol-cutoff; d['w']=np.maximum(0,1-np.abs(d.z)/bw); d['S']=d[share_col].astype(float)
    d['Tz']=d['T']*d['z']; d['TS']=d['T']*d['S']; d['zS']=d['z']*d['S']; d['TzS']=d['T']*d['z']*d['S']; d['y']=(d.receipt>=target).astype(float)
    d['fe']=d.state.astype(str)+'|'+d.district.astype(str)+'|'+d.assignment_year.astype(str)
    cols=['y','T','z','Tz','S','TS','zS','TzS']
    for base in ('rural_urban','school_category','management'):
        vals=pd.to_numeric(d[base],errors='coerce').fillna(-999).astype(int); cats=sorted(vals.unique())
        for c in cats[1:]:
            name=f'cv_{base}_{c}'; d[name]=(vals==c).astype(float); cols.append(name)
    # weighted demean by district x cohort fixed effect
    w=d.w.to_numpy(float)
    for col in cols:
        x=d[col].to_numpy(float)
        wx=pd.Series(w*x,index=d.index).groupby(d.fe).transform('sum').to_numpy(float)
        sw=pd.Series(w,index=d.index).groupby(d.fe).transform('sum').to_numpy(float)
        d[col]=x-np.divide(wx,sw,out=np.zeros_like(wx),where=sw>0)
    Xcols=['T','z','Tz','S','TS','zS','TzS']+[c for c in cols if c.startswith('cv_')]
    X=d[Xcols].to_numpy(float); y=d.y.to_numpy(float); w=d.w.to_numpy(float); clusters=d.state.astype(str).to_numpy()
    keep=np.isfinite(y)&np.isfinite(w)&(w>0)&np.all(np.isfinite(X),axis=1)
    X=X[keep];y=y[keep];w=w[keep];clusters=clusters[keep]
    if len(y)<800 or len(pd.unique(clusters))<8:return None
    fit=sm.WLS(y,X,weights=w).fit(cov_type='cluster',cov_kwds={'groups':clusters,'use_correction':True})
    j=Xcols.index('TS'); coef=float(fit.params[j]);se=float(fit.bse[j]);p=float(fit.pvalues[j])
    return {'n':int(fit.nobs),'clusters':int(len(pd.unique(clusters))),'interaction_per_10pp':coef*.1,
            'se_per_10pp':se*.1,'p':p,'ci_low_per_10pp':(coef-1.96*se)*.1,'ci_high_per_10pp':(coef+1.96*se)*.1,
            'fe':'district_year','adjusted':True}


def balance_jump(df: pd.DataFrame, col: str, cutoff: float, bw: float) -> dict | None:
    z=df[np.isfinite(df[col])&np.isfinite(df.enrol)].copy(); z=z[np.abs(z.enrol-cutoff)<=bw]
    if len(z)<500:return None
    z['T']=(z.enrol>=cutoff).astype(float);z['x']=z.enrol-cutoff;z['Tx']=z.T*0;z['Tx']=z['T']*z['x'];z['w']=np.maximum(0,1-np.abs(z.x)/bw)
    X=np.c_[np.ones(len(z)),z['T'],z['x'],z['Tx']];y=z[col].to_numpy(float);w=z.w.to_numpy(float)
    fit=sm.WLS(y,X,weights=w).fit(cov_type='cluster',cov_kwds={'groups':z.state.astype(str).to_numpy(),'use_correction':True}) if z.state.astype(str).nunique()>=8 else sm.WLS(y,X,weights=w).fit(cov_type='HC3')
    return {'tau':float(fit.params[1]),'se':float(fit.bse[1]),'p':float(fit.pvalues[1]),'n':int(fit.nobs)}


def asset_transition(base: pd.DataFrame, future: pd.DataFrame) -> pd.DataFrame:
    d=base.merge(future,on='pseudocode',how='left',suffixes=('_b','_o'))
    deterioration=[];upgrade=[]
    for _,r in d.iterrows():
        a=[];b=[]
        for k in ASSETS:
            bv=r.get(k+'_b');ov=r.get(k+'_o')
            if pd.isna(bv) or pd.isna(ov): continue
            if bv>=.5:a.append(1.0 if ov<.5 else 0.0)
            else:b.append(1.0 if ov>=.5 else 0.0)
        deterioration.append(np.mean(a) if a else np.nan);upgrade.append(np.mean(b) if b else np.nan)
    return pd.DataFrame({'pseudocode':d.pseudocode,'deterioration':deterioration,'upgrade':upgrade})


def fuzzy_fit(y,x,treat,state,cutoff,bw,fuzzy=False):
    y=np.asarray(y,float);x=np.asarray(x,float);treat=np.asarray(treat,float);st=pd.Series(state,dtype='object')
    m=np.isfinite(y)&np.isfinite(x)&np.isfinite(treat)&st.notna().to_numpy()&(np.abs(x-cutoff)<=bw)
    y=y[m];x=x[m];treat=treat[m];st=st.to_numpy()[m]
    if len(y)<400 or pd.Series(st).nunique()<8:return None
    kw=dict(y=y,x=x,c=cutoff,p=1,q=2,kernel='tri',h=bw,b=max(bw*1.5,bw+5),cluster=pd.Categorical(st).codes,vce='cr3',masspoints='adjust',bwcheck=max(5,min(20,int(round(bw/2)))))
    if fuzzy:kw['fuzzy']=treat
    try:
        r=rdrobust(**kw);ci=pull_last(r,'ci');return {'tau':pull_last(r,'coef'),'se':pull_last(r,'se'),'p':pull_last(r,'pv'),'ci_low':ci[0],'ci_high':ci[1],'n':len(y)}
    except Exception as e:return {'error':repr(e),'n':len(y)}


def main() -> None:
    ay=os.environ['ASSIGN_YEAR']; ai=YEARS.index(ay); repo=os.environ['HF_DATASET_REPO'];token=os.environ['HF_TOKEN']
    prev=YEARS[ai-1] if ai>0 else None; correct_report=YEARS[ai+3]; grant_fy=YEARS[ai+2]
    out=Path(f'studies/composite_school_grant/outputs/full_formula_audit/cohort_{ay}');shutil.rmtree(out,ignore_errors=True);out.mkdir(parents=True)
    con=duckdb.connect();con.execute('PRAGMA threads=4');con.execute("PRAGMA memory_limit='10GB'")
    timing_rows=[];fidelity_rows=[];bandwidth_rows=[];state_rows=[];social_rows=[];balance_rows=[];fuzzy_rows=[];raw_rates=[];stack_parts=[];validation={}
    with tempfile.TemporaryDirectory(prefix=f'full_formula_{ay}_') as td:
        root=Path(td)
        comp,diag=build_composition_year(con,repo,token,ay,root,out);validation['assignment_composition']=diag
        pcomp,pdiag=build_composition_year(con,repo,token,prev,root,out);validation['previous_composition']=pdiag
        e8p=build_e8_year(con,repo,token,ay,root,out)
        finance={}
        for lag in range(0,5):
            if ai+lag<len(YEARS): finance[lag]=load_financial_year(con,repo,token,YEARS[ai+lag],root,out)
        abase=build_asset_year(con,repo,token,ay,root,out)
        future_assets={}
        for oi in range(ai+3,len(YEARS)):
            oy=YEARS[oi];future_assets[oy]=build_asset_year(con,repo,token,oy,root,out)

        prev_cols=','.join(f'p.{g}_share AS prev_{g}_share' for g in GROUPS)
        # Local samples are materialized only around each cutoff, never uploaded as artifacts.
        for spec in SCHEDULE:
            end=spec['end']; cutoff=end+.5; upper=spec['upper']; lower=spec['lower']; bw=spec['bw']; maxbw=bw*1.75
            local=con.execute(f"""
              SELECT a.*,e.enrol18,{prev_cols}
              FROM read_parquet({lit(str(comp))}) a
              LEFT JOIN read_parquet({lit(str(e8p))}) e USING(pseudocode)
              LEFT JOIN read_parquet({lit(str(pcomp))}) p USING(pseudocode)
              WHERE a.enrol BETWEEN {cutoff-maxbw} AND {cutoff+maxbw}
            """).df();local['assignment_year']=ay
            for lag,fp in finance.items():
                f=con.execute(f"SELECT * FROM read_parquet({lit(str(fp))})").df()
                d=local.merge(f,on='pseudocode',how='left')
                for uname,codes in [('core_state_local',CORE_STATE_LOCAL),('broad_state',BROAD_STATE),('all_udise_government',ALL_UDISE_GOVERNMENT)]:
                    z=d[universe_mask(d.management,codes)].copy();y=np.where(np.isfinite(z.receipt),(z.receipt>=upper).astype(float),np.nan)
                    est=fit_rdrobust(y,z.enrol,z.state,cutoff,bw)
                    if est and 'tau' in est:
                        timing_rows.append({'assignment_year':ay,'grant_financial_year':grant_fy,'outcome_year':YEARS[ai+lag],'lag':lag,
                                            'threshold':spec['label'],'threshold_end':end,'target':upper,'universe':uname,**est})
                if lag<=3:
                    zb=d[universe_mask(d.management,BROAD_STATE)].copy();zb['y']=(zb.receipt>=upper).astype(float)
                    for state,g in zb.groupby('state',dropna=True):
                        est=fit_local(g,'y',cutoff,bw,'district')
                        if est:
                            state_rows.append({'assignment_year':ay,'lag':lag,'outcome_year':YEARS[ai+lag],'threshold':spec['label'],'state':state,
                                               'metric':'first_stage_receipt_atleast_target',**est})

            # Correctly timed financial fidelity at +3.
            f=con.execute(f"SELECT * FROM read_parquet({lit(str(finance[3]))})").df();d=local.merge(f,on='pseudocode',how='left')
            for uname,codes in [('core_state_local',CORE_STATE_LOCAL),('broad_state',BROAD_STATE),('all_udise_government',ALL_UDISE_GOVERNMENT)]:
                z=d[universe_mask(d.management,codes)].copy();r=z.receipt.to_numpy(float);q=z.expenditure.to_numpy(float);vr=np.isfinite(r);vq=np.isfinite(q)
                outs={
                    'receipt_exact_lower':np.where(vr,np.isclose(r,lower).astype(float),np.nan),
                    'receipt_exact_upper':np.where(vr,np.isclose(r,upper).astype(float),np.nan),
                    'receipt_atleast_upper':np.where(vr,(r>=upper).astype(float),np.nan),
                    'receipt_above_lower':np.where(vr,(r>lower).astype(float),np.nan),
                    'receipt_positive':np.where(vr,(r>0).astype(float),np.nan),
                    'expenditure_exact_lower':np.where(vq,np.isclose(q,lower).astype(float),np.nan),
                    'expenditure_exact_upper':np.where(vq,np.isclose(q,upper).astype(float),np.nan),
                    'expenditure_atleast_upper':np.where(vq,(q>=upper).astype(float),np.nan),
                    'expenditure_above_lower':np.where(vq,(q>lower).astype(float),np.nan),
                    'expenditure_positive':np.where(vq,(q>0).astype(float),np.nan),
                }
                # Winsorization is local and side-agnostic within each threshold/universe sample.
                if vr.sum()>100: outs['receipt_w99']=np.where(vr,np.minimum(r,np.nanquantile(r,.99)),np.nan)
                if vq.sum()>100: outs['expenditure_w99']=np.where(vq,np.minimum(q,np.nanquantile(q,.99)),np.nan)
                for name,y in outs.items():
                    est=fit_rdrobust(y,z.enrol,z.state,cutoff,bw)
                    if est and 'tau' in est:
                        rec={'assignment_year':ay,'grant_financial_year':grant_fy,'report_year':correct_report,'threshold':spec['label'],
                             'threshold_end':end,'lower_target':lower,'upper_target':upper,'nominal_jump':spec['jump'],'universe':uname,
                             'sample':'all','outcome':name,'bw':bw,**est}
                        if name in ('receipt_w99','expenditure_w99'):rec['recorded_transmission_ratio']=rec['tau']/spec['jump']
                        fidelity_rows.append(rec)
                if uname=='broad_state':
                    for variant in ('primary','strict'):
                        m=pm_safe_mask(z,end,variant);zz=z.loc[m].copy()
                        rr=zz.receipt.to_numpy(float);qq=zz.expenditure.to_numpy(float);vrr=np.isfinite(rr);vqq=np.isfinite(qq)
                        for name,y in {
                            'receipt_atleast_upper':np.where(vrr,(rr>=upper).astype(float),np.nan),
                            'expenditure_atleast_upper':np.where(vqq,(qq>=upper).astype(float),np.nan),
                        }.items():
                            est=fit_rdrobust(y,zz.enrol,zz.state,cutoff,bw)
                            if est and 'tau' in est:fidelity_rows.append({'assignment_year':ay,'grant_financial_year':grant_fy,'report_year':correct_report,
                                'threshold':spec['label'],'threshold_end':end,'lower_target':lower,'upper_target':upper,'nominal_jump':spec['jump'],
                                'universe':uname,'sample':f'pm_safe_{variant}','outcome':name,'bw':bw,**est})

            # Bandwidth sensitivity for primary first stage, broad state universe.
            z=d[universe_mask(d.management,BROAD_STATE)].copy();y=np.where(np.isfinite(z.receipt),(z.receipt>=upper).astype(float),np.nan)
            for mult in (.5,.75,1.0,1.33,1.67):
                hb=max(5,bw*mult);est=fit_rdrobust(y,z.enrol,z.state,cutoff,hb)
                if est and 'tau' in est:bandwidth_rows.append({'assignment_year':ay,'threshold':spec['label'],'bw':hb,'bw_multiplier':mult,**est})

            # Raw local rates, state fidelity at +3.
            zb=d[universe_mask(d.management,BROAD_STATE)].copy();
            # Standardized rows for a common stacked multi-cutoff RD within this cohort.
            stp=zb[np.abs(zb.enrol-cutoff)<=bw].copy()
            if len(stp):
                stp['threshold']=spec['label'];stp['T']=(stp.enrol>=cutoff).astype(float);stp['z_scaled']=(stp.enrol-cutoff)/bw
                stp['w_stack']=np.maximum(0,1-np.abs(stp.z_scaled));stp['y_stack']=np.where(np.isfinite(stp.receipt),(stp.receipt>=upper).astype(float),np.nan)
                stack_parts.append(stp[['state','threshold','T','z_scaled','w_stack','y_stack']])
            left=zb[(zb.enrol>=cutoff-bw)&(zb.enrol<cutoff)];right=zb[(zb.enrol>=cutoff)&(zb.enrol<=cutoff+bw)]
            for side,g,target in [('left',left,lower),('right',right,upper)]:
                raw_rates.append({'assignment_year':ay,'threshold':spec['label'],'side':side,'target':target,'n':len(g),
                    'receipt_positive':float(np.nanmean(g.receipt.to_numpy(float)>0)) if len(g) else None,
                    'receipt_atleast_target':float(np.nanmean(g.receipt.to_numpy(float)>=target)) if len(g) else None,
                    'receipt_exact_target':float(np.nanmean(np.isclose(g.receipt.to_numpy(float),target))) if len(g) else None,
                    'mean_receipt_w99':float(np.nanmean(np.minimum(g.receipt.to_numpy(float),np.nanquantile(g.receipt.to_numpy(float),.99)))) if len(g) and np.isfinite(g.receipt).sum()>20 else None})
            zb['y']=(zb.receipt>=upper).astype(float)
            for state,g in zb.groupby('state',dropna=True):
                est=fit_local(g,'y',cutoff,bw,'district')
                if est:state_rows.append({'assignment_year':ay,'lag':3,'outcome_year':correct_report,'threshold':spec['label'],'state':state,'metric':'first_stage_receipt_atleast_target_canonical',**est})
                rr=g[g.enrol>=cutoff];ll=g[g.enrol<cutoff]
                if len(rr)>=20:
                    state_rows.append({'assignment_year':ay,'lag':3,'outcome_year':correct_report,'threshold':spec['label'],'state':state,'metric':'right_side_absolute_fidelity',
                        'n':len(rr),'value':float(np.nanmean(rr.receipt.to_numpy(float)>=upper)),'exact_value':float(np.nanmean(np.isclose(rr.receipt.to_numpy(float),upper)))})

            # Predetermined composition balance and heterogeneity at +3.
            for g in GROUPS:
                col=f'prev_{g}_share'
                bal=balance_jump(zb,col,cutoff,bw)
                if bal:balance_rows.append({'assignment_year':ay,'threshold':spec['label'],'group':g,**bal})
                h=generalized_social_interaction(zb,col,cutoff,bw,upper)
                if h:social_rows.append({'assignment_year':ay,'threshold':spec['label'],'group':g,'composition_source':'predetermined_previous_year',**h})

            # Fuzzy-RD facility sensitivity using correctly timed reported high-band receipt as endogenous administrative treatment.
            base_assets=con.execute(f"SELECT * FROM read_parquet({lit(str(abase))})").df()
            base_local=zb[['pseudocode','enrol','state','management','enrol18','receipt']].merge(base_assets,on='pseudocode',how='left')
            for oy,op in future_assets.items():
                fut=con.execute(f"SELECT * FROM read_parquet({lit(str(op))})").df();tr=asset_transition(base_local[['pseudocode']+ASSETS],fut)
                zz=base_local.merge(tr,on='pseudocode',how='left');t=np.where(np.isfinite(zz.receipt),(zz.receipt>=upper).astype(float),np.nan)
                for sample,mask in [('all',np.ones(len(zz),bool)),('pm_safe_primary',pm_safe_mask(zz,end,'primary'))]:
                    szz=zz.loc[mask];tt=t[mask];x=szz.enrol.to_numpy(float);st=szz.state.to_numpy(dtype=object)
                    for outcome in ('deterioration','upgrade'):
                        yy=szz[outcome].to_numpy(float);m=np.isfinite(yy)&np.isfinite(tt)
                        if m.sum()<300:continue
                        fs=fuzzy_fit(tt[m],x[m],tt[m],st[m],cutoff,bw,False);rf=fuzzy_fit(yy[m],x[m],tt[m],st[m],cutoff,bw,False);fr=fuzzy_fit(yy[m],x[m],tt[m],st[m],cutoff,bw,True)
                        common={'assignment_year':ay,'threshold':spec['label'],'report_year':correct_report,'outcome_year':oy,'sample':sample,'outcome':outcome}
                        if fs and 'tau' in fs:fuzzy_rows.append({**common,'estimand':'first_stage_reported_high_receipt',**fs})
                        if rf and 'tau' in rf:fuzzy_rows.append({**common,'estimand':'reduced_form_threshold',**rf})
                        if fr and 'tau' in fr:fuzzy_rows.append({**common,'estimand':'fuzzy_RD_reported_high_receipt',**fr})
            print('DONE THRESHOLD',ay,spec['label'],flush=True)

    # Family corrections within cohort x threshold across social groups / balance variables.
    for rows,key in [(social_rows,'p'),(balance_rows,'p')]:
        for thr in sorted(set(r['threshold'] for r in rows)):
            idx=[i for i,r in enumerate(rows) if r['threshold']==thr and r.get(key) is not None and np.isfinite(r[key])]
            if idx:
                q=multipletests([rows[i][key] for i in idx],method='fdr_bh')[1]
                for i,v in zip(idx,q):rows[i]['q_bh']=float(v)

    stacked_rows=[]
    if stack_parts:
        sd=pd.concat(stack_parts,ignore_index=True).dropna(subset=['y_stack','state'])
        # Common discontinuity with cutoff-specific intercepts and smooth slopes.
        th=pd.get_dummies(sd['threshold'],prefix='thr',drop_first=True,dtype=float)
        Xparts=[pd.Series(1.0,index=sd.index,name='const'),sd['T'].astype(float),sd['z_scaled'].astype(float),(sd['T']*sd['z_scaled']).rename('Tz')]
        for c in th.columns:
            Xparts.append(th[c].rename(c));Xparts.append((th[c]*sd['z_scaled']).rename(c+'_z'));Xparts.append((th[c]*sd['T']*sd['z_scaled']).rename(c+'_Tz'))
        X=pd.concat(Xparts,axis=1).to_numpy(float);y=sd.y_stack.to_numpy(float);w=sd.w_stack.to_numpy(float);cl=sd.state.astype(str).to_numpy()
        keep=np.isfinite(y)&np.isfinite(w)&(w>0)&np.all(np.isfinite(X),axis=1);X=X[keep];y=y[keep];w=w[keep];cl=cl[keep]
        if len(y)>1000 and len(pd.unique(cl))>=8:
            fit=sm.WLS(y,X,weights=w).fit(cov_type='cluster',cov_kwds={'groups':cl,'use_correction':True})
            tau=float(fit.params[1]);se=float(fit.bse[1]);p=float(fit.pvalues[1]);stacked_rows.append({'assignment_year':ay,'estimand':'common_stacked_formula_jump','tau':tau,'se':se,'p':p,'ci_low':tau-1.96*se,'ci_high':tau+1.96*se,'n':int(fit.nobs),'clusters':int(len(pd.unique(cl)))})
    write_csv(out/'stacked_formula.csv',stacked_rows)
    write_csv(out/'timing.csv',timing_rows);write_csv(out/'fidelity.csv',fidelity_rows);write_csv(out/'bandwidth_sensitivity.csv',bandwidth_rows)
    write_csv(out/'state_response.csv',state_rows);write_csv(out/'social_heterogeneity.csv',social_rows);write_csv(out/'predetermined_balance.csv',balance_rows)
    write_csv(out/'fuzzy_facility.csv',fuzzy_rows);write_csv(out/'raw_local_rates.csv',raw_rates)
    (out/'validation.json').write_text(json.dumps(validation,indent=2,default=float),encoding='utf-8')

    lines=[f'# Full four-threshold CSG cohort audit: {ay}','',f'Grant FY: {grant_fy}. Correct UDISE reporting round: {correct_report}.','']
    for spec in SCHEDULE:
        rows=[r for r in fidelity_rows if r['threshold']==spec['label'] and r['universe']=='broad_state' and r['sample']=='all' and r['outcome'] in ('receipt_atleast_upper','receipt_w99','expenditure_w99')]
        lines.append(f"## {spec['end']}/{spec['end']+1}")
        lines.append(spec['interpretation'])
        for r in rows:
            val=100*r['tau'] if r['outcome']=='receipt_atleast_upper' else r['tau'];unit=' pp' if r['outcome']=='receipt_atleast_upper' else ' Rs'
            extra=f"; transmission ratio {r.get('recorded_transmission_ratio',float('nan')):.3f}" if 'recorded_transmission_ratio' in r else ''
            lines.append(f"- {r['outcome']}: {val:+.2f}{unit} (p={r['p']:.4g}){extra}")
        t=[r for r in timing_rows if r['threshold']==spec['label'] and r['universe']=='broad_state']
        if t:
            best=max(t,key=lambda r:r['tau']);lines.append(f"- strongest observed lag in 0..4: +{best['lag']} ({100*best['tau']:.2f} pp)")
        lines.append('')
    (out/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8');print('\n'.join(lines),flush=True)
    con.close()

if __name__=='__main__':
    main()
