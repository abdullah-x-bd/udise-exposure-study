from __future__ import annotations
import csv, json, math, os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.stats.multitest import multipletests

ROOT=Path(os.environ.get('INPUT_ROOT','inputs'))
OUT=Path('studies/composite_school_grant/outputs/full_formula_audit/final');OUT.mkdir(parents=True,exist_ok=True)
THRESHOLDS=['30_31','100_101','250_251','1000_1001']
LABEL={'30_31':'30/31','100_101':'100/101','250_251':'250/251','1000_1001':'1000/1001'}
TARGET={'30_31':25000,'100_101':50000,'250_251':75000,'1000_1001':100000}
LOWER={'30_31':10000,'100_101':25000,'250_251':50000,'1000_1001':75000}
JUMP={'30_31':15000,'100_101':25000,'250_251':25000,'1000_1001':25000}


def gather(name):
    files=list(ROOT.rglob(name))
    arr=[]
    for f in files:
        try:
            d=pd.read_csv(f)
            if len(d):d['_source']=str(f);arr.append(d)
        except Exception:pass
    return pd.concat(arr,ignore_index=True) if arr else pd.DataFrame()

def write(name,df):
    df.to_csv(OUT/name,index=False)

def ivw(g,coef='tau',se='se'):
    z=g[[coef,se]].replace([np.inf,-np.inf],np.nan).dropna()
    z=z[z[se]>0]
    if len(z)==0:return {'k':0,'tau':np.nan,'se':np.nan,'ci_low':np.nan,'ci_high':np.nan,'p':np.nan}
    w=1/z[se].to_numpy(float)**2;t=float(np.sum(w*z[coef])/np.sum(w));s=float(np.sqrt(1/np.sum(w)));p=math.erfc(abs(t/s)/math.sqrt(2)) if s>0 else np.nan
    return {'k':len(z),'tau':t,'se':s,'ci_low':t-1.96*s,'ci_high':t+1.96*s,'p':p}

fidelity=gather('fidelity.csv');timing=gather('timing.csv');state=gather('state_response.csv');social=gather('social_heterogeneity.csv');balance=gather('predetermined_balance.csv');fuzzy=gather('fuzzy_facility.csv');stacked=gather('stacked_formula.csv');bandwidth=gather('bandwidth_sensitivity.csv');raw=gather('raw_local_rates.csv')
stable=gather('stable_entitlement_pairs.csv');persistent=gather('persistent_mismatch.csv');density=gather('density_placebo.csv');cross=gather('minimal_crossing_summary.csv');cycle=gather('cycle_fidelity_by_band.csv')

# Core threshold x cohort matrix.
core=fidelity[(fidelity.get('universe')=='broad_state')&(fidelity.get('sample')=='all')] if len(fidelity) else pd.DataFrame()
rows=[]
for th in THRESHOLDS:
    for ay in sorted(core.assignment_year.unique()) if len(core) else []:
        g=core[(core.threshold==th)&(core.assignment_year==ay)]
        rec={'threshold':th,'assignment_year':ay,'lower_target':LOWER[th],'upper_target':TARGET[th],'nominal_jump':JUMP[th]}
        for out,name,scale in [('receipt_atleast_upper','first_stage_pp',100),('receipt_exact_upper','exact_upper_jump_pp',100),('receipt_w99','receipt_jump_rs',1),('expenditure_w99','expenditure_jump_rs',1),('expenditure_atleast_upper','expenditure_threshold_jump_pp',100)]:
            q=g[g.outcome==out]
            if len(q):
                r=q.iloc[0];rec[name]=float(r.tau)*scale;rec[name+'_p']=float(r.p)
                if out in ('receipt_w99','expenditure_w99'):rec[name.replace('_rs','_transmission_ratio')]=float(r.tau)/JUMP[th]
        pm=fidelity[(fidelity.threshold==th)&(fidelity.assignment_year==ay)&(fidelity.get('universe')=='broad_state')&(fidelity.get('sample')=='pm_safe_primary')&(fidelity.outcome=='receipt_atleast_upper')]
        if len(pm):rec['pm_safe_first_stage_pp']=100*float(pm.iloc[0].tau);rec['pm_safe_p']=float(pm.iloc[0].p)
        rows.append(rec)
headline=pd.DataFrame(rows);write('threshold_cohort_headline.csv',headline)

# Fixed-effect meta summaries across cohorts.
meta=[]
for th in THRESHOLDS:
    for out in ['receipt_atleast_upper','receipt_exact_upper','receipt_w99','expenditure_w99','expenditure_atleast_upper']:
        g=core[(core.threshold==th)&(core.outcome==out)]
        r=ivw(g);meta.append({'threshold':th,'outcome':out,**r,'scaled_value':100*r['tau'] if ('atleast' in out or 'exact' in out) else r['tau'],'transmission_ratio':r['tau']/JUMP[th] if out in ('receipt_w99','expenditure_w99') else np.nan})
meta=pd.DataFrame(meta);write('threshold_meta_summary.csv',meta)

# Timing summaries.
timing_summary=[]
if len(timing):
    t=timing[timing.universe=='broad_state']
    for th in THRESHOLDS:
        for ay in sorted(t.assignment_year.unique()):
            g=t[(t.threshold==th)&(t.assignment_year==ay)].dropna(subset=['tau'])
            if not len(g):continue
            best=g.loc[g.tau.idxmax()]
            timing_summary.append({'threshold':th,'assignment_year':ay,'best_lag':int(best.lag),'best_jump_pp':100*best.tau,
                **{f'lag_{int(r.lag)}_pp':100*r.tau for _,r in g.iterrows()}})
timing_summary=pd.DataFrame(timing_summary);write('timing_summary.csv',timing_summary)

# Stacked common formula fingerprint.
write('stacked_formula_all_cohorts.csv',stacked)
stack_meta=ivw(stacked) if len(stacked) else {}

# State speed x strength x fidelity per threshold, cohort-averaged.
state_typ=[]
if len(state):
    fs=state[state.metric.isin(['first_stage_receipt_atleast_target','first_stage_receipt_atleast_target_canonical'])].copy()
    # remove duplicate canonical lag3 rows if ordinary lag3 already exists
    fs['is_canonical']=(fs.metric=='first_stage_receipt_atleast_target_canonical')
    fs=fs.sort_values('is_canonical').drop_duplicates(['assignment_year','threshold','state','lag'],keep='last')
    absf=state[state.metric=='right_side_absolute_fidelity'].copy()
    for (th,st),g in fs.groupby(['threshold','state']):
        curve=g.groupby('lag').tau.mean().sort_index();peak=float(curve.max()) if len(curve) else np.nan
        n80=np.nan
        if np.isfinite(peak) and peak>0:
            cand=curve[curve>=.8*peak]
            if len(cand):n80=float(cand.index.min())
        strength=float(curve.get(3,np.nan));af=absf[(absf.threshold==th)&(absf.state.astype(str)==str(st))]
        state_typ.append({'threshold':th,'state':st,'cohorts':g.assignment_year.nunique(),'strength_t3_pp':100*strength if np.isfinite(strength) else np.nan,
          'peak_pp':100*peak if np.isfinite(peak) else np.nan,'n80_lag':n80,'right_side_fidelity':float(af.value.mean()) if len(af) else np.nan,
          'right_side_exact_fidelity':float(af.exact_value.mean()) if len(af) else np.nan})
state_typ=pd.DataFrame(state_typ);write('state_speed_strength_fidelity.csv',state_typ)

# Social heterogeneity meta + FDR across groups within each threshold.
social_meta=[]
if len(social):
    for (th,gname),g in social.groupby(['threshold','group']):
        z=g.rename(columns={'interaction_per_10pp':'tau','se_per_10pp':'se'});r=ivw(z)
        signs=(np.sign(z.tau.dropna())==np.sign(r['tau'])).mean() if np.isfinite(r['tau']) and len(z) else np.nan
        social_meta.append({'threshold':th,'group':gname,'effect_pp_per_10pp':100*r['tau'],'se_pp':100*r['se'],'p':r['p'],'k':r['k'],'sign_agreement':signs})
social_meta=pd.DataFrame(social_meta)
if len(social_meta):
    social_meta['q_bh']=np.nan
    for th,g in social_meta.groupby('threshold'):
        idx=g.index[g.p.notna()];social_meta.loc[idx,'q_bh']=multipletests(social_meta.loc[idx,'p'],method='fdr_bh')[1]
write('social_heterogeneity_meta.csv',social_meta)

# Balance family audit.
balance_meta=[]
if len(balance):
    for (th,gname),g in balance.groupby(['threshold','group']):
        r=ivw(g);balance_meta.append({'threshold':th,'group':gname,**r})
balance_meta=pd.DataFrame(balance_meta);write('predetermined_balance_meta.csv',balance_meta)

# Fuzzy outcome summary only; no positive headline fishing.
fuzzy_sum=[]
if len(fuzzy):
    z=fuzzy[(fuzzy.estimand=='fuzzy_RD_reported_high_receipt')&(fuzzy['sample']=='all')]
    for (th,outcome),g in z.groupby(['threshold','outcome']):
        r=ivw(g);fuzzy_sum.append({'threshold':th,'outcome':outcome,**r})
fuzzy_sum=pd.DataFrame(fuzzy_sum);write('fuzzy_facility_meta.csv',fuzzy_sum)

# Density true vs placebo percentile by threshold-year and averaged.
density_summary=[]
if len(density):
    for (year,th),g in density.groupby(['academic_year','threshold_label']):
        tr=g[g.kind=='true'];pl=g[g.kind=='placebo']
        if not len(tr):continue
        v=float(tr.iloc[0].heaping_adjusted_asymmetry);pct=float((pl.heaping_adjusted_asymmetry<=v).mean()) if len(pl) else np.nan
        density_summary.append({'academic_year':year,'threshold':th,'asymmetry':v,'placebo_percentile':pct,'n_placebos':len(pl)})
density_summary=pd.DataFrame(density_summary);write('density_true_summary.csv',density_summary)

# Write longitudinal inputs through for convenience.
for nm,df in [('stable_entitlement_pairs.csv',stable),('persistent_mismatch.csv',persistent),('cycle_fidelity_by_band.csv',cycle),('minimal_crossing_summary.csv',cross)]:write(nm,df)

# Figures.
if len(headline):
    fig,ax=plt.subplots(figsize=(10,5))
    for ay,g in headline.groupby('assignment_year'):
        gg=g.set_index('threshold').reindex(THRESHOLDS);ax.plot([LABEL[t] for t in THRESHOLDS],gg.first_stage_pp,marker='o',label=ay)
    ax.axhline(0,linewidth=.8);ax.set_ylabel('Jump in P(recorded receipt ≥ new band), pp');ax.set_xlabel('Statutory CSG boundary');ax.set_title('The full CSG formula fingerprint across four cohorts');ax.legend(title='Assignment enrolment');fig.tight_layout();fig.savefig(OUT/'figure_formula_fingerprint.png',dpi=200);plt.close(fig)

    tr=headline.groupby('threshold').agg(receipt=('receipt_jump_transmission_ratio','mean'),expenditure=('expenditure_jump_transmission_ratio','mean')).reindex(THRESHOLDS)
    fig,ax=plt.subplots(figsize=(9,5));x=np.arange(len(tr));w=.35;ax.bar(x-w/2,tr.receipt,w,label='Recorded receipt');ax.bar(x+w/2,tr.expenditure,w,label='Recorded expenditure');ax.axhline(1,linestyle='--',linewidth=1);ax.set_xticks(x,[LABEL[t] for t in tr.index]);ax.set_ylabel('Recorded discontinuity / nominal statutory jump');ax.set_title('Recorded formula transmission ratio');ax.legend();fig.tight_layout();fig.savefig(OUT/'figure_transmission_ratio.png',dpi=200);plt.close(fig)

if len(state_typ):
    s=state_typ[state_typ.threshold=='250_251'].dropna(subset=['n80_lag','strength_t3_pp'])
    if len(s):
        fig,ax=plt.subplots(figsize=(10,7));ax.scatter(s.n80_lag,s.strength_t3_pp,s=35)
        for _,r in s.iterrows():
            if r.strength_t3_pp>=25 or r.n80_lag>=3.5:ax.annotate(str(r.state),(r.n80_lag,r.strength_t3_pp),fontsize=7,xytext=(3,3),textcoords='offset points')
        ax.set_xlabel('Administrative latency N80, UDISE rounds');ax.set_ylabel('Mean T+3 formula response, pp');ax.set_title('State implementation: speed × strength at 250/251');fig.tight_layout();fig.savefig(OUT/'figure_state_speed_strength_250.png',dpi=200);plt.close(fig)

if len(persistent):
    p=persistent.copy();p['label']=p.target.map(lambda x:f'₹{int(x/1000)}k')
    fig,ax=plt.subplots(figsize=(9,5));x=np.arange(len(p));ax.bar(x,100*p.p_never_meets);ax.set_xticks(x,p.label);ax.set_ylabel('% never meeting recorded nominal target');ax.set_title('Persistent recorded mismatch among schools with stable entitlement (≥3 cycles)');fig.tight_layout();fig.savefig(OUT/'figure_persistent_mismatch.png',dpi=200);plt.close(fig)

# Human-readable report.
lines=['# Full Four-Threshold Composite School Grant Audit','',
'## Executive result','']
if len(meta):
    m=meta[meta.outcome=='receipt_atleast_upper'].set_index('threshold')
    for th in THRESHOLDS:
        if th in m.index:
            r=m.loc[th];lines.append(f"- {LABEL[th]}: pooled recorded high-band first stage {100*r.tau:+.2f} pp (95% CI {100*r.ci_low:+.2f} to {100*r.ci_high:+.2f}; {int(r.k)} cohorts).")
if stack_meta:
    lines+=['',f"Across thresholds, the cohort-level stacked formula fingerprint meta-estimate is {100*stack_meta.get('tau',float('nan')):+.2f} pp (95% CI {100*stack_meta.get('ci_low',float('nan')):+.2f} to {100*stack_meta.get('ci_high',float('nan')):+.2f})."]
lines+=['','## Recorded rupee transmission','']
if len(meta):
    for th in THRESHOLDS:
        a=meta[(meta.threshold==th)&(meta.outcome=='receipt_w99')];b=meta[(meta.threshold==th)&(meta.outcome=='expenditure_w99')]
        if len(a):
            rr=a.iloc[0];ee=b.iloc[0] if len(b) else None
            lines.append(f"- {LABEL[th]}: recorded receipt discontinuity Rs {rr.tau:+,.0f} ({rr.transmission_ratio:.2f} of nominal jump)"+(f"; expenditure Rs {ee.tau:+,.0f} ({ee.transmission_ratio:.2f})." if ee is not None else '.'))
lines+=['','## Administrative timing','']
if len(timing_summary):
    for th in THRESHOLDS:
        g=timing_summary[timing_summary.threshold==th]
        if len(g):
            vc=g.best_lag.value_counts();lines.append(f"- {LABEL[th]}: modal strongest lag +{int(vc.index[0])} in {int(vc.iloc[0])}/{len(g)} cohorts.")
lines+=['','## Stable entitlement and persistence','']
if len(persistent):
    for _,r in persistent.iterrows():lines.append(f"- Nominal Rs {int(r.target):,}: among schools staying in this band for >=3 cycles, {100*r.p_never_meets:.2f}% never meet the target in the UDISE record and {100*r.p_below_at_least_2_cycles:.2f}% are below it in at least two cycles.")
lines+=['','## Manipulation falsification','']
if len(cross):
    for th in THRESHOLDS:
        a=cross[(cross.threshold_label==th)&(cross.metric=='p_land_exact_first_above')]
        if len(a):lines.append(f"- {LABEL[th]}: exact-first-above landing differs from matched placebos by {100*a.iloc[0].mean_true_minus_placebo:+.3f} pp on average.")
lines+=['','## Interpretation guardrails','',
'- The four boundaries are valid for auditing the administrative formula fingerprint. They are not equally clean CSG-only outcome experiments.',
'- The 250/251 boundary remains the strongest quasi-experimental CSG benchmark after the PM POSHAN-safe restriction.',
'- 100/101 and 1000/1001 overlap other enrolment-linked PM POSHAN rules; downstream outcome effects there cannot automatically be attributed solely to CSG.',
'- The <=30 Rs 10,000 band requires cohort-specific historical verification before older-cohort causal interpretation.',
'- UDISE grant receipt is an administrative report, not independently audited PFMS cash delivery. Below-target records therefore cannot be called funding denial without payment-ledger linkage.']
(OUT/'FULL_FOUR_THRESHOLD_AUDIT.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
