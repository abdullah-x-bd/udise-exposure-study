from __future__ import annotations

import csv, json, math, os, runpy, shutil
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
import statsmodels.api as sm

T = runpy.run_path('studies/composite_school_grant/timing_core/run_timing_core.py', run_name='full_formula_longitudinal_lib')
YEARS=T['YEARS']; build=T['build']; lit=T['lit']
BROAD={1,2,3,6,89,90}
SCHEDULE=[
    {'label':'30_31','end':30,'lower':10000,'upper':25000,'jump':15000,'density_window':25,'approach':15},
    {'label':'100_101','end':100,'lower':25000,'upper':50000,'jump':25000,'density_window':45,'approach':20},
    {'label':'250_251','end':250,'lower':50000,'upper':75000,'jump':25000,'density_window':70,'approach':20},
    {'label':'1000_1001','end':1000,'lower':75000,'upper':100000,'jump':25000,'density_window':175,'approach':50},
]
CYCLES=[('2019-20','2022-23'),('2020-21','2023-24'),('2021-22','2024-25'),('2022-23','2025-26')]
PLACEBOS={30:[50,75],100:[75,125,150],250:[200,225,275,300],1000:[850,900,950,1050,1100,1150]}


def write_csv(path, rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:path.write_text('',encoding='utf-8');return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys:keys.append(k)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def target_expr(e='a.enrol'):
    return f"CASE WHEN {e} BETWEEN 1 AND 30 THEN 10000 WHEN {e} BETWEEN 31 AND 100 THEN 25000 WHEN {e} BETWEEN 101 AND 250 THEN 50000 WHEN {e} BETWEEN 251 AND 1000 THEN 75000 WHEN {e}>1000 THEN 100000 END"


def heap(v):
    if v%100==0:return 5
    if v%50==0:return 4
    if v%25==0:return 3
    if v%10==0:return 2
    if v%5==0:return 1
    return 0


def density_fit(cmap, c, window, zone=5):
    lo=max(1,c-window); hi=c+window+1
    xs=np.arange(lo,hi+1); y=np.array([cmap.get(int(x),0) for x in xs],float)
    z=(xs-(c+.5))/max(window,1); h=np.array([heap(int(x)) for x in xs])
    sensitive=(xs>=c-zone)&(xs<=c+zone)
    X=np.column_stack([np.ones(len(xs)),z,z*z,z*z*z]+[(h==k).astype(float) for k in range(1,6)])
    fit=~sensitive
    if fit.sum()<12:return None
    try:
        m=sm.GLM(y[fit],X[fit],family=sm.families.Poisson()).fit(maxiter=200,disp=0);pred=m.predict(X)
    except Exception:
        b=np.linalg.lstsq(X[fit],np.log1p(y[fit]),rcond=None)[0];pred=np.maximum(0,np.expm1(X@b))
    above=(xs>=c+1)&(xs<=c+zone);below=(xs>=c-zone)&(xs<=c-1)
    oa,ea=y[above].sum(),pred[above].sum();ob,eb=y[below].sum(),pred[below].sum()
    if ea<=0 or eb<=0:return None
    return {'threshold_end':c,'obs_above':float(oa),'expected_above':float(ea),'excess_ratio_above':float(oa/ea-1),
            'obs_below':float(ob),'expected_below':float(eb),'excess_ratio_below':float(ob/eb-1),
            'heaping_adjusted_asymmetry':float((oa/ea-1)-(ob/eb-1)),
            'count_at_threshold_end':int(cmap.get(c,0)),'count_first_above':int(cmap.get(c+1,0))}


def dist_standardized(a, c):
    if len(a)==0:return (np.nan,np.nan)
    aa=a.copy();aa['distance']=c-aa.x0
    ex=[];f5=[]
    for _,g in aa.groupby('distance'):
        if len(g)>=5:
            ex.append(float((g.x1==c+1).mean()));f5.append(float(((g.x1>=c+1)&(g.x1<=c+5)).mean()))
    return (float(np.mean(ex)) if ex else np.nan,float(np.mean(f5)) if f5 else np.nan)


def crossing_summary(z,c,width,kind,true_label):
    a=z[(z.x0>=c-width)&(z.x0<=c)].copy()
    if len(a)<50:return None
    a['needed']=(c+1)-a.x0;a['increment']=a.x1-a.x0
    exact=a[a.x1==c+1];first5=a[(a.x1>=c+1)&(a.x1<=c+5)]
    sx,s5=dist_standardized(a,c)
    return {'threshold_label':true_label,'threshold_end':c,'kind':kind,'approach_width':width,'n_approach':len(a),
            'p_land_exact_first_above':float((a.x1==c+1).mean()),'p_land_first5_above':float(((a.x1>=c+1)&(a.x1<=c+5)).mean()),
            'p_increment_exact_minimum':float((a['increment']==a['needed']).mean()),'distance_std_exact':sx,'distance_std_first5':s5,
            'n_exact_first_above':len(exact),'p_exact_revert_below_next':float((exact.x2<=c).mean()) if len(exact) else np.nan,
            'n_first5_above':len(first5),'p_first5_revert_below_next':float((first5.x2<=c).mean()) if len(first5) else np.nan}


def main():
    out=Path('studies/composite_school_grant/outputs/full_formula_audit/longitudinal');shutil.rmtree(out,ignore_errors=True);out.mkdir(parents=True)
    con=duckdb.connect();con.execute('PRAGMA threads=4');con.execute("PRAGMA memory_limit='10GB'")
    panel=build(con,os.environ['HF_DATASET_REPO'],os.environ['HF_TOKEN'],out)

    # Build four correctly aligned entitlement-report cycles once.
    parts=[]
    for i,(ay,ry) in enumerate(CYCLES):
        parts.append(f"""SELECT {i} cycle_index,{lit(ay)} assignment_year,{lit(ry)} report_year,a.pseudocode,a.state,a.management,a.enrol,
          {target_expr('a.enrol')} target,f.receipt,f.expenditure
          FROM read_parquet({lit(str(panel))}) a LEFT JOIN read_parquet({lit(str(panel))}) f
          ON a.pseudocode=f.pseudocode AND f.academic_year={lit(ry)}
          WHERE a.academic_year={lit(ay)} AND a.management IN ({','.join(map(str,sorted(BROAD)))}) AND a.enrol>=1""")
    con.execute('CREATE TEMP TABLE cycles AS '+' UNION ALL '.join(parts))
    con.execute("ALTER TABLE cycles ADD COLUMN meets BOOLEAN");con.execute("UPDATE cycles SET meets=receipt>=target WHERE receipt IS NOT NULL AND target IS NOT NULL")
    con.execute("ALTER TABLE cycles ADD COLUMN exact BOOLEAN");con.execute("UPDATE cycles SET exact=ABS(receipt-target)<0.5 WHERE receipt IS NOT NULL AND target IS NOT NULL")

    # Single-cycle fidelity by band and state.
    cycle_rows=[]
    q=con.execute("""SELECT assignment_year,report_year,target,COUNT(*) n,COUNT(receipt) n_reported,
      AVG(CASE WHEN receipt>0 THEN 1.0 ELSE 0.0 END) p_positive,AVG(CAST(meets AS DOUBLE)) p_meets,AVG(CAST(exact AS DOUBLE)) p_exact,
      AVG(CASE WHEN receipt IS NOT NULL THEN LEAST(receipt,target*2.0)/target END) mean_capped_ratio,
      AVG(CASE WHEN receipt IS NOT NULL THEN GREATEST(target-receipt,0)/target END) mean_shortfall_share
      FROM cycles WHERE target IS NOT NULL GROUP BY 1,2,3 ORDER BY 1,3""").fetchdf()
    cycle_rows=q.to_dict('records');write_csv(out/'cycle_fidelity_by_band.csv',cycle_rows)

    state_cycle=con.execute("""SELECT assignment_year,state,target,COUNT(*) n,AVG(CAST(meets AS DOUBLE)) p_meets,AVG(CAST(exact AS DOUBLE)) p_exact,
      AVG(CASE WHEN receipt IS NOT NULL THEN LEAST(receipt,target*2.0)/target END) mean_capped_ratio
      FROM cycles WHERE target IS NOT NULL GROUP BY 1,2,3 HAVING COUNT(*)>=50""").fetchdf().to_dict('records')
    write_csv(out/'cycle_fidelity_by_state_band.csv',state_cycle)

    # Stable entitlement across adjacent correct cycles.
    pair=con.execute("""SELECT a.pseudocode,a.state,a.target,a.cycle_index cycle0,b.cycle_index cycle1,a.assignment_year year0,b.assignment_year year1,
      a.receipt r0,b.receipt r1,a.meets m0,b.meets m1,a.exact e0,b.exact e1
      FROM cycles a JOIN cycles b ON a.pseudocode=b.pseudocode AND b.cycle_index=a.cycle_index+1
      WHERE a.target=b.target AND a.target IS NOT NULL""").fetchdf()
    stable_rows=[];state_stable=[]
    for keys,g in pair.groupby(['year0','year1','target'],dropna=False):
        rr=g[['r0','r1']].dropna();corr=float(rr.r0.corr(rr.r1)) if len(rr)>=20 and rr.r0.std()>0 and rr.r1.std()>0 else np.nan
        below=g[g.m0==False];meet0=g[g.m0==True]
        stable_rows.append({'year0':keys[0],'year1':keys[1],'target':keys[2],'n':len(g),'n_both_reported':len(rr),
          'p_meet_both':float(((g.m0==True)&(g.m1==True)).mean()),'p_below_both':float(((g.m0==False)&(g.m1==False)).mean()),
          'p_exact_both':float(((g.e0==True)&(g.e1==True)).mean()),'recovery_if_below':float((below.m1==True).mean()) if len(below) else np.nan,
          'relapse_if_met':float((meet0.m1==False).mean()) if len(meet0) else np.nan,'mean_abs_receipt_change':float((rr.r1-rr.r0).abs().mean()) if len(rr) else np.nan,
          'receipt_corr':corr})
    for (state,target),g in pair.groupby(['state','target']):
        if len(g)<100:continue
        below=g[g.m0==False];meet0=g[g.m0==True]
        state_stable.append({'state':state,'target':target,'n_pairs':len(g),'p_meet_both':float(((g.m0==True)&(g.m1==True)).mean()),
          'p_below_both':float(((g.m0==False)&(g.m1==False)).mean()),'recovery_if_below':float((below.m1==True).mean()) if len(below) else np.nan,
          'relapse_if_met':float((meet0.m1==False).mean()) if len(meet0) else np.nan})
    write_csv(out/'stable_entitlement_pairs.csv',stable_rows);write_csv(out/'stable_entitlement_state.csv',state_stable)

    # Persistent mismatch among schools whose target is unchanged over >=3 observed cycles.
    hist=con.execute("""SELECT pseudocode,state,target,COUNT(*) cycles,COUNT(receipt) reported,
      SUM(CASE WHEN meets THEN 1 ELSE 0 END) meet_cycles,SUM(CASE WHEN meets=FALSE THEN 1 ELSE 0 END) below_cycles,
      SUM(CASE WHEN exact THEN 1 ELSE 0 END) exact_cycles
      FROM cycles WHERE target IS NOT NULL GROUP BY 1,2,3 HAVING COUNT(*)>=3""").fetchdf()
    persistent=[]
    for target,g in hist.groupby('target'):
        persistent.append({'target':target,'schools_3plus_cycles':len(g),'p_never_meets':float((g.meet_cycles==0).mean()),
          'p_always_meets':float((g.meet_cycles==g.cycles).mean()),'p_below_at_least_2_cycles':float((g.below_cycles>=2).mean()),
          'p_exact_every_cycle':float((g.exact_cycles==g.cycles).mean()),'mean_meet_cycle_share':float((g.meet_cycles/g.cycles).mean())})
    write_csv(out/'persistent_mismatch.csv',persistent)
    persistent_state=[]
    for (state,target),g in hist.groupby(['state','target']):
        if len(g)<100:continue
        persistent_state.append({'state':state,'target':target,'n':len(g),'p_never_meets':float((g.meet_cycles==0).mean()),
          'p_below_at_least_2_cycles':float((g.below_cycles>=2).mean()),'mean_meet_cycle_share':float((g.meet_cycles/g.cycles).mean())})
    write_csv(out/'persistent_mismatch_state.csv',persistent_state)

    # Heaping-adjusted density and local placebos, all eight years.
    density_rows=[]
    for year in YEARS:
        vals=con.execute(f"SELECT CAST(enrol AS INTEGER) e,COUNT(*) n FROM read_parquet({lit(str(panel))}) WHERE academic_year={lit(year)} AND management IN ({','.join(map(str,sorted(BROAD)))}) AND enrol BETWEEN 1 AND 1250 GROUP BY 1").fetchall()
        cmap={int(e):int(n) for e,n in vals}
        for spec in SCHEDULE:
            c=spec['end'];r=density_fit(cmap,c,spec['density_window'])
            if r:density_rows.append({'academic_year':year,'threshold_label':spec['label'],'kind':'true',**r})
            for p in PLACEBOS[c]:
                w=max(20,min(spec['density_window'],100));rr=density_fit(cmap,p,w)
                if rr:density_rows.append({'academic_year':year,'threshold_label':spec['label'],'kind':'placebo','placebo_for':c,**rr})
    write_csv(out/'density_placebo.csv',density_rows)

    # Longitudinal minimum crossing / reversion around every true boundary and matched placebos.
    cross_rows=[]
    for i in range(len(YEARS)-2):
        y0,y1,y2=YEARS[i:i+3]
        # Pull only schools relevant to any threshold/placebo; upper bound 1200.
        d=con.execute(f"""SELECT a.pseudocode,a.enrol x0,b.enrol x1,c.enrol x2,a.state FROM read_parquet({lit(str(panel))}) a
          JOIN read_parquet({lit(str(panel))}) b ON a.pseudocode=b.pseudocode AND b.academic_year={lit(y1)}
          JOIN read_parquet({lit(str(panel))}) c ON a.pseudocode=c.pseudocode AND c.academic_year={lit(y2)}
          WHERE a.academic_year={lit(y0)} AND a.management IN ({','.join(map(str,sorted(BROAD)))}) AND a.enrol BETWEEN 1 AND 1200""").fetchdf()
        for spec in SCHEDULE:
            c=spec['end'];r=crossing_summary(d,c,spec['approach'],'true',spec['label'])
            if r:cross_rows.append({'start_year':y0,'middle_year':y1,'end_year':y2,**r})
            for p in PLACEBOS[c]:
                rr=crossing_summary(d,p,spec['approach'],'placebo',spec['label'])
                if rr:cross_rows.append({'start_year':y0,'middle_year':y1,'end_year':y2,**rr})
    write_csv(out/'minimal_crossing_all_thresholds.csv',cross_rows)

    # Aggregate true-vs-placebo differences for interpretation.
    cross_summary=[]
    cr=pd.DataFrame(cross_rows)
    if len(cr):
        for label,g in cr.groupby('threshold_label'):
            for metric in ['p_land_exact_first_above','p_increment_exact_minimum','p_exact_revert_below_next','distance_std_exact']:
                true=g[g.kind=='true'].groupby('start_year')[metric].mean();pl=g[g.kind=='placebo'].groupby('start_year')[metric].mean()
                j=pd.concat([true.rename('true'),pl.rename('placebo')],axis=1).dropna()
                if len(j):cross_summary.append({'threshold_label':label,'metric':metric,'cohorts':len(j),'mean_true':float(j.true.mean()),'mean_placebo':float(j.placebo.mean()),'mean_true_minus_placebo':float((j.true-j.placebo).mean())})
    write_csv(out/'minimal_crossing_summary.csv',cross_summary)

    # Remove school-level panel material before artifact upload.
    shutil.rmtree(out/'year',ignore_errors=True)
    try:(out/'panel.parquet').unlink()
    except FileNotFoundError:pass
    try:(out/'build_manifest.json').unlink()
    except FileNotFoundError:pass

    report=['# Full formula longitudinal audit','',
      'Stable-entitlement analyses use the four correctly aligned assignment/report cycles. They describe UDISE-recorded administrative reliability and do not by themselves prove actual cash non-receipt.',
      '', '## Persistent mismatch by nominal target']
    for r in persistent:
        report.append(f"- Rs {int(r['target']):,}: never meets target in >=3 stable cycles {100*r['p_never_meets']:.2f}%; below target in >=2 cycles {100*r['p_below_at_least_2_cycles']:.2f}%; always meets {100*r['p_always_meets']:.2f}%")
    report+=['','## Longitudinal crossing vs matched placebos']
    for r in cross_summary:
        if r['metric']=='p_land_exact_first_above':report.append(f"- {r['threshold_label']}: exact-first-above true-minus-placebo {100*r['mean_true_minus_placebo']:+.3f} pp across {r['cohorts']} windows")
    (out/'RESULTS.md').write_text('\n'.join(report),encoding='utf-8');print('\n'.join(report),flush=True)
    con.close()

if __name__=='__main__':main()
